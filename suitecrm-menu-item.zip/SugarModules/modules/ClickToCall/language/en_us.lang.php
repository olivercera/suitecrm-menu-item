<?php

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings['LBL_CLICKTOCALL_TITLE'] = 'SuiteCRM Click to Call (Asterisk)';

$mod_strings['LBL_CLICKTOCALL_ASTERISK_IP']   = 'IP';
$mod_strings['LBL_CLICKTOCALL_ASTERISK_PORT'] = 'Port';

$mod_strings['LBL_CLICKTOCALL_ASTERISK_USER'] = 'User';
$mod_strings['LBL_CLICKTOCALL_ASTERISK_PASS'] = 'Password';

$mod_strings['LBL_CLICKTOCALL_ASTERISK_CHANNELIN']        = 'Channel In';
$mod_strings['LBL_CLICKTOCALL_ASTERISK_CHANNELINCONTEXT'] = 'Channel In Context';

$mod_strings['LBL_CLICKTOCALL_ASTERISK_CHANNELOUT']       = 'Channel Out';
$mod_strings['LBL_CLICKTOCALL_ASTERISK_CHANNELOUTCONTEXT'] = 'Channel Out Context';

$mod_strings['LBL_CLICKTOCALL_ASTERISK_CALLERID']  = 'Caller ID';
$mod_strings['LBL_CLICKTOCALL_ASTERISK_VARIABLES'] = 'Variables';

