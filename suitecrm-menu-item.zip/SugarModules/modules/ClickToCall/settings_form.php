<?php

$settingsForm['clicktocall_asterisk_ip']   = array('default' => '127.0.0.1', 'placeholder' => '127.0.0.1');
$settingsForm['clicktocall_asterisk_port'] = array('default' => '5038', 'placeholder' => '5038');
$settingsForm['clicktocall_asterisk_user'] = array('default' => '', 'placeholder' => '');
$settingsForm['clicktocall_asterisk_pass'] = array('default' => '', 'placeholder' => '');

$settingsForm['clicktocall_channelIn']        = array('default' => 'local', 'placeholder' => 'local');
$settingsForm['clicktocall_channelInContext'] = array('default' => '', 'placeholder' => 'from-users');

$settingsForm['clicktocall_channelOut']        = array('default' => 'local', 'placeholder' => 'local');
$settingsForm['clicktocall_channelOutContext'] = array('default' => '', 'placeholder' => 'from-users');

$settingsForm['clicktocall_callerId'] = array('default' => '', 'placeholder' => '0');
$settingsForm['clicktocall_variables'] = array('default' => '', 'placeholder' => 'var_extension=$extension;var_num_llamar=$numberCall');


