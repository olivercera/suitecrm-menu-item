<?php

if (!isset($mod_strings)) {
    $mod_strings = array();
}

$mod_strings['LBL_CLICKTOCALL_TITLE'] = 'SuiteCRM Click to Call (Asterisk)';
$mod_strings['LBL_CLICKTOCALL_DESC'] = '';

$mod_strings['LBL_CLICKTOCALL_CONFIGURATION_TITLE'] = 'Click to Call Configuration';
$mod_strings['LBL_CLICKTOCALL_CONFIGURATION_DESC'] = 'Asterisk Configuration';

