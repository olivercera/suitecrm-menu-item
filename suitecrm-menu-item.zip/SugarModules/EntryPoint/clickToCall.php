<?php

$entry_point_registry['clickToCall'] = array(
    'file' => 'modules/ClickToCall/sendToAsterik.php',
    'auth' => false
);

